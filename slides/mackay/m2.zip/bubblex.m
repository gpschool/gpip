function ret = bubblex ( M , v , L , alpha , x , indicator ) 
# do a bubble tour of a gaussian 
# making plots versus x as we go 
 if ((nargin != 6)&&(nargin != 5))
    usage ("bubblex ( M , v , L , alpha , x [,indicator] )");
  endif
#if (nargin != 6)
#	plainplot = 1 ; 
#	style = "-@63" ; # unused
#else 
#	plainplot = 0 ; 
#endif

	plainplot = 1 ; 
	style = "-@64" ; # unused

pointstyle = "@13" ; 
vl=[] ; 	
for l=1:L
	v = alpha * v + sqrt((1.0-alpha^2)) * randn(size(v))*M  ;
	xvtot = [ x' , v' ] ;
	vl(l,:) = [v] ;
	if ( plainplot ) 
	    if ( nargin==6)
		gplot xvtot u 1:2 w linespoints 6 4 , indicator u 1:2 w l 7 8 ;
	    else
		gplot xvtot u 1:2 w linespoints 6 4 ;
	    endif
	else
		plot(x,v,style)
	endif
endfor
ret = vl ;
endfunction

function ret = randb ( p ) 
# randb ( p ) 
# returns 0/1 with probability 1-p / p 
# using randn crudely
if(nargin != 1 ) 
	usage ("randb(p)");
endif
ret = ( rand(size(p)) < p ) ;


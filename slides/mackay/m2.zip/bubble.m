function ret = bubble ( M , v , L , alpha ) 
# do a bubble tour of a gaussian 
 if (nargin != 4)
    usage ("bubble ( M , v , L , alpha )");
  endif

vl=[] ; 	
for l=1:L
	v = alpha * v + (1.0-alpha^2) * randn(size(v)) 
	vl(l,:) = [v] 
	plot(v)
endfor
ret = vl
endfunction

# eiglist=[];
# J = 20 ; jitter = 1.0 ; dj = 0.3 ;
#  for j=1:J
#	 jitter = dj * jitter ; 
#		C = covR( x, x , R,R, jitter ) ;
#	eiglist(j,: ) = sort(eig(C)') ;
# input( "next;")
# endfor ;
# gset autos xy
# gset ytics
# plot(eiglist);
# eiglist


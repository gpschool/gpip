# usage 
# demo1d
r=2;
S=10;                     # number of samples
movieS=3;                     # number of samples
initgnu();			# set up graphics
#
# define data
#
goahead=input("Two dimensional Gaussian distribution","s") ;
if ( !(goahead=="n") ) 
 x=[1,2] ;
 o=[1,0] ;
 t=[1] ;
gset xrange [0.5:2.5] ;
 demoxot(x,o,t,r,S,movieS);
endif

goahead=input("Six dimensional Gaussian distribution","s") ;
if ( !(goahead=="n") ) 
 x=[1,2,3,4,5,6] ;
 o=[1,1,0,0,0,1] ;
 t=[1,1.25,0.1] ;
initgnu();			# set up graphics
 demoxot(x,o,t,r,S,movieS);
endif

goahead=input("Six dimensional Gaussian distribution","s") ;
if ( !(goahead=="n") ) 
 x=[0, 1, 1.5, 2, 2.5, 3,3.5,4,4.5,5,5.5,6,7] ;
 gset xrange [-0.5:7.5] ;
 o=[0,0,0,0,0,1,0,1,0,1,0,0,0] ;
 t=[-1,-1.25,-0.1] ;
 demoxot(x,o,t,r,S,movieS);
endif


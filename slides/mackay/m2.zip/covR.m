function ret = covR ( xa , xb , ra , rb , jitter )
# make  covariance matrix, not necessarily square, for gaussian process 
  if (nargin != 5)
    usage ("covR (xa,xb,r,jitter) - xa,xb is vector, ra,rb is vector like x");
  endif
global A ;
global Rdjcm ; 

	s = size(xa);
	Sa=s(2);	
	s = size(xb);
	Sb=s(2);	
	xi = ones(size(xb))' * xa ;
	xj = xi' ;
	xi = ones(size(xa))' * xb ;
	dij = xi .- xj ;
	
	D = dij .^ 2 ;
	for i=1:Sa
		for j=1:Sb
			r2(i,j)  = (ra(1,i)^2 + rb(1,j)^2) ;
			ir2(i,j) =  1.0 / sqrt( 1.0/ra(1,i)^2 + 1.0/rb(1,j)^2 );
	if ( Rdjcm == 1 ) 
			C(i,j) =  (1.0/r2(i,j)) * A * exp ( - D(i,j) / r2(i,j) )  ;
	elseif ( Rdjcm == 2 ) # uniform variance version 
			C(i,j) =  (ra(1,i)*rb(1,j)/r2(i,j)) * A * exp ( - D(i,j) / r2(i,j) )  ;
	else # mng
			C(i,j) =  (ir2(i,j)) * A * exp ( - 0.5 * D(i,j) / r2(i,j) )  ;
	endif
		endfor
	endfor
	if ( jitter && (size(xb)==size(xa)) ) 
		C = C + jitter * eye ( Sa ) ;
	endif
	ret = C ; 
endfunction

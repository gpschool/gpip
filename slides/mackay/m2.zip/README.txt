This demonstration of Gaussian processes, by David MacKay, was first written
1997, updated 2006 to make it run appropriately slowly on modern computers.

It is known to work with  
GNU Octave, version 2.0.17 (i686-pc-linux-gnu)

It probably does _not_ work with later versions of octave, which are not 
backward-compatible.

To obtain my colour scheme, you need to have my .gnuplot file and my .Xdefaults file,
which define the colours. (Actually, maybe you only need the .Xdefaults.)

Method used to make archive: 
tar cvf m2.tar *.m .gnuplot .Xdefaults README.txt
zip m2.zip     *.m .gnuplot .Xdefaults README.txt


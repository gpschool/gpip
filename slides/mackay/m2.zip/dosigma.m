# showdata = 1 gives pause, 0 gives no pause.
#
if ( showdata >= 0 ) 
  if(showdata==1 )
	command = sprintf ( "input (\"next: sigma = %4g\");" , sigma ) ; 
	eval(command) ; 
  else 
	sigma
  endif	
endif
if ( showdata >= 0 ) 
	indicator = mybox( -0.7 , 0.4 , -2 , sigma ) ;
endif
logpr = interpolate(x,t,xtest, 1,showdata,sigma^2,indicator) ; 
sigmalogpr(++n,:) = [sigma, logpr, exp(logpr) ] ;

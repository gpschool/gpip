function ret = covO ( xa , xb , r , alpha , beta , jitter )
# make  covariance matrix, not necessarily square, for gaussian process 
  if (nargin != 6)
    usage ("cov (xa,xb,r,jitter) - xa,xb is vector, r is scalar");
  endif
global A ;


	s = size(xa);
	Sa=s(2);	
	s = size(xb);
	Sb=s(2);	
	xi = ones(size(xb))' * xa ;
	xj = xi' ;
	xi = ones(size(xa))' * xb ;
	dij = xi .- xj ;
	
	D = dij .^ 2 ;
	for i=1:Sa
		for j=1:Sb
			F(i,j) = alpha + beta * (xa(1,i) * xb(1,j)) ;
			C(i,j) = F(i,j) * A * exp ( - 0.5 * D(i,j) / (2*r^2)  )  ;
		endfor
	endfor
	if ( jitter && (size(xb)==size(xa)) ) 
		C = C + jitter * eye ( Sa ) ;
	endif
	ret = C ; 
endfunction


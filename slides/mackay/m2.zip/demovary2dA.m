function ret = demovary2dA(x,t,r,Amin,Amax,pausetime,memory,data,Nr,Ud)
# usage 
# demovary2d(x,t,r,Amin,Amax,ptimre,memory,data,Nr)
# do a demo using inputs x, etc. - came from demoxot
#  if datainc = 0 then data are left out
#  if datainc = 1 then data are included
  if (nargin != 6 && nargin != 7 && nargin != 8 && nargin != 9 && nargin!=10 )
    usage ("demovaryr(x,t,r,Amin,Amax,ptime[,memory[,data[,Nr]]])");
  endif
  if (nargin != 7  && nargin != 8 && nargin != 9 && nargin!=10 )
	memory = 0.8 ; 
  endif
  if ( nargin != 8 && nargin != 9 && nargin!=10 )
	data = 2 ; 
  endif
  if ( nargin != 9 && nargin!=10 )
	Nr=20; # must be 2 or more
  endif
  if (  nargin!=10 )
	Ud=2; # number of ups and downs
  endif
verbose = 0 ;
title = 0 ;
global jitter ;
global A;
restore25sq;

firsttime=1;
s=size(x); X=s(2);
style="@14";
lstyle = "-@64" ; # style for line samples
mstyle = "-4" ; # style for mean (green lines -14)
dlr = log(Amax/Amin) / ( Nr-1) ; 
dr0 = exp ( dlr ) ;
tt = t ;
o=[1,1];
logPr = [] ;
gset label 1 "A" at -2.2,-2.2 center
while ( 1 ) 
 A = Amin ; 
 dr = dr0 ;
 for  ud = 1:Ud
   for nr = 1:Nr ## number of distinct hyperparameter values to visit
	CCIM ;
	if ( title ) 
		command = sprintf ("gset title \"P( y1 , y2 | A = %4f )\"", C(1,1));
	    	eval (command);
	else
		gset title "P(y1,y2|A)";
	endif
	contourstrue ;
	indicator = mybox( -2.4 , 0.4 , -2 , sqrt(A) ) ; 

	if ( data == 0 ) 
		gplot c1 u 1:2 w l 3 6 , c2 u 1:2 w l 3 6 ;
	else
		plotcontours ;
		if ( firsttime ) 
			lp = logprob2d(CI,t)  ;
			logPr(nr,:) = [ A , C(1,1) , lp , exp(lp) ] ;
		endif
	endif
	pause(pausetime) ; 

	A = A * dr ;
     endfor # nr
     if ( firsttime == 1 )
       firstime = 0 ;
       s = input("ready to go back down?");
     endif
     dr = 1/dr ;
     A = A * dr ;

 endfor # ud
 s = input("to repeat slower, type factor - ");
	purge_tmp_files ;
 if ( s ) 
 else break ; endif
 pausetime = pausetime * s ; 
endwhile
gset nolabel 1
gset title "";
ret = logPr ;



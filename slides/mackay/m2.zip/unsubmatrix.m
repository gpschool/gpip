function ret = unsubmatrix ( A , o ) 
# o specifies the columns that were omit.
# unsubmatrix puts them back, set to zero.
 if ((nargin != 2))
    usage ("unsubmatrix(A,o)");
  endif
s = size(A) ; 
subheight = s(1) ; subwidth = s(2) ; 
s = size( o ) ; 
height = s(2) ; width = height ;

newl=0;
C=zeros(height,width) ;
for l=1:height
	if ( !o(l) ) 
		newl++;
		newm=0;
		for m =1:width
			if ( !o(m) ) 
				newm++;
				C(l,m)=A(newl,newm);
			endif
		endfor
	endif
		
endfor
ret = C ;
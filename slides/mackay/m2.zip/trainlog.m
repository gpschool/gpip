function w = trainlog ( w , L , eta , alpha ) 

# train ( w , L , eta , alpha )
#			trains a single neuron from weight vector w
#                       using global data in x,t
#                       for a number of loops L
#                       with learning rate eta; 
# 			there is weight decay alpha
#
# 	 		the final weights are returned
# also the weight history is logged to wl every dT its
# using the global variable T

	global x ;
	global t ;

	global dT ; 
	global T ; 
	global wl ; 

	for l = 1:L

		a = x * w  ;
		y = sigmoid(a) ;
		e = t - y   ;
		gw = x' * e ;
		w = w + eta * ( gw - alpha * w )  ;

# keep log of w if T is a multiple of dT

		if ( round(T/dT) == (T/dT) )
			wl(:,T/dT) = w ;
		endif
		T ++ ;

	endfor

endfunction

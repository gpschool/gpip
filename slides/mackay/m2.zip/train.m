function w = train ( w , L , eta , alpha ) 

# train ( w , L , eta , alpha )
#			trains a single neuron from weight vector w
#                       using global data in x,t
#                       for a number of loops L
#                       with learning rate eta; 
# 			there is weight decay alpha
#
# 	 		the final weights are returned

	global x ;
	global t ;

	for l = 1:L

		a = x * w  ;
		y = sigmoid(a) ;
		e = t - y   ;
		gw = x' * e ;
		w = w + eta * ( gw - alpha * w )  ;

	endfor

endfunction

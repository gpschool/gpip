function ret= demovaryAP(x,o,t,r,Amin,Amax,movieS,memory,data,Nr,Ud)
# usage 
# demovaryAP(x,o,t,r,Amin,Amax,movieS,memory,data)
# do a demo using inputs x, etc. - came from demoxot
#  if datainc = 0 then data are left out
#  if datainc = 1 then data are included
# works out logP along the way.
# only makes sense if data=1
  if (nargin != 9 && nargin != 7 && nargin != 8 && nargin!=10 && nargin != 11)
    usage ("demovaryAP(x,o,t,r,Amin,Amax,movieS[,memory[,data]])");
  endif
  if (nargin != 9  && nargin != 8 && nargin!=10 && nargin != 11)
	memory = 0.8 ; 
  endif
  if ( nargin != 9 && nargin!=10 && nargin != 11)
	data = 2 ; 
  endif
  if ( nargin!=10 && nargin != 11)
	Nr=15; # must be 2 or more
  endif
  if (  nargin != 11)
	Ud=3; # number of ups and downs
  endif
verbose = 0 ;
jitter = 1e-4 ;
global A ;
firsttime=1;
pausetime=0.2;
s=size(x); X=s(2);
dotitle = 0 ;
#style="@13";
#lstyle = "-@63" ; # style for line samples
#plstyle = "-@53" ; # style for line samples, posterior
#mstyle = "-4" ; # style for mean (green lines -14)
dlr = log(Amax/Amin) / ( Nr-1) ; 
dr0 = exp ( dlr ) ;
firstrun = 1 ; 
logPr = [] ;

while ( 1 ) 

A = Amin ; 
gset label 1 "A" at -0.5,-0.2 center
dr = dr0 ;
for  ud = 1:Ud
for nr = 1:Nr
	if(dotitle)
 		command = sprintf ("gset title \"A = %f\"", A);
 	    	eval (command);
	else
		gset title "" ;
	endif
	if ( verbose ) 
		A
		fflush(stdout) ; 
	endif
	CCIM ;
	indicator = mybox( -0.75 , 0.5 , 0 , sqrt(A) ) ; 
	if ( data == 0 ) 
		v=randn(size(x))*M ;
		vl = bubblex( M , v , movieS , memory , x ) ;
	else
		infer ;

#		if(firsttime) 
#			plot ( xsub,t,style  ) ; 
#			input("press return");
#			firsttime = 0 ; 
#		endif

		dv = randn(size(x)) * pp  ;
		if ( movieS > 0 ) 
		    vl = bubblexmd( pp , dv , movieS , memory , x , mean,xsub,t , indicator ) ;
		else # make a green picture 

			gplot xsubt u 1:2 w p 1 4 , xmsd u 1:2:3 w error 4 2 , xmean u 1:2 w l 4 2 , indicator u 1:2 w l 7 8 ;
			pause(pausetime);

		endif

		if ( firstrun)
#			keyboard
			lp = logprob2d(CsubI,t)  ;
			logPr(nr,:) = [ A , C(1,1) , lp , exp(lp) ] ;
		endif
	endif

	A = A * dr ;
endfor # nr
dr = 1/dr ;
A = A * dr ;
if(firstrun) firstrun=0 ; endif

endfor # ud

s = input("to repeat, type a number - ");
if ( s )
	pausetime = pausetime * s ;
else
 break ; endif
endwhile

gset title ""
gset nolabel 1

ret = logPr ; 



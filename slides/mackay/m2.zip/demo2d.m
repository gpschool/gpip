function demo2d(x,o,t,r,S,movieS,memory,verbose) 
# usage 
# demo2d(x,o,t)
# do a demo using inputs x, etc.
# special case where x is 2d.
  if (nargin != 6 && nargin != 7 && nargin != 8)
    usage ("demo2d(x,o,t,r,S,movieS[,memory[,verbose]])");
  endif
  if (nargin != 7  && nargin != 8)
	memory = 0.8 ; 
  endif
  if ( nargin != 8)
	verbose = 1 ; 
  endif

jitter = 1e-4 ;
s=size(x); X=s(2);
if (X!=2) 
	print "error, size of x wrong \n";
	break ;
endif
restore25sq;

#
# Make covariance matrix
#
CCIM ;

contours;
##gset title "P(t1,t2)";
gset title "P(y1,y2)";
gplot c1 u 1:2 w l 2 7 , c2 u 1:2 w l 3 6 ;
input("press return");

# Make S samples and show them
v=randn(S,X)*M ;
## gset title "P(t1,t2)";
## v is the points from the prior.  "3" is stars style
gplot c1 u 1:2 w l 2 7 , c2 u 1:2 w l 3 6 , v u 1:2 w points 6 4;

# noto , xsub , CIsub , CIsubM , postCov , mean , postcovM , pp , pvars, psds
# are obtained from x,o,CI,t
infer();
input("demo2d - press return");

# keyboard
msd = [ mean , psds ] ;
# msd = [ xsub , tmp , psds ] ;
					# show the data on page
data = [  1,-2.5 ; 1,2.5 ] ; #  lines
halfdata = [  1,-2.5 ; 1,-1 ] ;
#gset title "t1 = 1";
gset title "y1 = 1";
gplot  c1 u 1:2 w l 2 7 , c2 u 1:2 w l 3 6 , v u 1:2 w points 6 4 , data u 1:2 w l 1 3 ;
input("press return");

#gset title "P(t2|t1=1)";
gset title "P(y2|y1=1)";
gplot  c1 u 1:2 w l 2 7 , c2 u 1:2 w l 3 6 , halfdata u 1:2 w l 1 4 , msd u 1:2:3 w error 4 1 ;
input("press return");

# straight away show the samples that go through the data points
# --- make a load of independent samples
vv = randn(S,X) * pp  ;
posts = vv + ones(S,1) * mean ; 
gplot  c1 u 1:2 w l 2 7 , c2 u 1:2 w l 3 6 ,  halfdata u 1:2 w l 1 4 , posts u 1:2 w points 5 2 ;
# gplot  c1 u 1:2 w l 2 7 , c2 u 1:2 w l 3 6 ,  halfdata u 1:2 w l 1 3 , posts u 1:2 w points 5 3 , mean u 1:2 w p 4 1, msd u 1:2:3 w error 4 1 ;
# input("press return");
gset title "";

############################ end ###########################

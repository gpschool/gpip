function ret = bubblexm ( M , v , L , alpha , x , mean , style ) 
# do a bubble tour of a gaussian 
# making plots versus x as we go 
# includes a mean vector 
 if ((nargin != 6)&&(nargin != 7))
    usage ("bubblex ( M , v , L , alpha , x , m [,style] )");
  endif
if (nargin != 7)
# need to fix up style
	style = "-@63" ;
endif
vl=[] ; 	
for l=1:L
	v = alpha * v + sqrt((1.0-alpha^2)) * randn(size(v))*M  ;
	vtot = v + mean ;
	vl(l,:) = [vtot] ;
	plot(x,vtot,style) ;
endfor
ret = vl ;
endfunction

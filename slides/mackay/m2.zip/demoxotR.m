function demoxotR(x,o,t,r,S,movieS,memory,verbose)
# usage 
#  demoxotR(x,o,t,r,S,movieS,memory,verbose)
# demoxot-like, except that r is a vector
# do a demo using inputs x, etc.
  if (nargin != 6 && nargin != 7 && nargin != 8)
    usage ("demoxotR(x,o,t,r,S,movieS[,memory[,verbose]])");
  endif
  if (nargin != 7  && nargin != 8)
	memory = 0.8 ; 
  endif
  if ( nargin != 8)
	verbose = 1 ; 
  endif

global jitter ;
# temporary measure:
# jitter = 1e-1 ;
showdataalone = 0 ;

s=size(x); X=s(2);
# S=10;                     # number of samples
# movieS=3;                     # number of samples
style="@14";
lstyle  = "-@64" ; # style for line samples
plstyle = "-@54" ; # style for line samples, posterior
mstyle = "-4" ; # style for mean 
#  initgnu();			# set up graphics done elsewhere
#
# Make covariance matrix
#
CCIMR ; 

# initialize one random sample and do a movie
v=randn(size(x))*M ;
if ( verbose ) # show this one sample
	if ( X == 2 ) 
#		show this one point in a contour plot
		v=[1.2,-0.3]*M;
		command = sprintf("input(\"y = (%4.1f ,%4.1f )\")",v(1,1),v(1,2));
		contours;
		restore25sq;
		gplot c1 u 1:2 w l 2 7 , c2 u 1:2 w l 3 6 , v u 1:2 w p 6 3;
		restore525;
		gset label 5 "y1" at 0.9,0.9 right
		gset label 6 "y2" at 2.1,0.9 left
		eval(command);
#		input("press return");
	endif
	plot ( x,v,lstyle) ;
	input("demoxot : one sample : press return");
endif
if ( !((verbose <= 1) && (X==2)) )  #  i.e. skip this if X==2 and not very verbose
 vl = bubblex( M , v , movieS , memory , x ) ;
 input("press return");
endif

# Make S samples and show them - from prior
v=randn(S,X)*M ;
infer();
if ( showdataalone )					
  plot ( x,v,lstyle)
  input("press return");
	plot ( xsub,t,style  ) ; 
	input("demoxot : press return");
endif

plot ( x,v,lstyle, xsub,t,style) ;
input("demoxot : press return");

gplot  xmsd u 1:2:3 w error 4 2 , xmean u 1:2 w l 4 2 , xsubt u 1:2 w p 1 3 ;
input("demoxot : press return--");

# plot ( xsub,t,"@13",xtest,msd,"~41") # this plots m and sd as functions of x
# plot ( xsub,t,"@13",xtest,tmp,psds,"~41") # this plots mean(tmp vs xtest and psds versus xsub. clearly the errorbar stuff is not working.

purge_tmp_files ;
# straight away show the samples that go through the data points
# --- make a load of independent samples
vv = randn(S,X) * pp  ;
posts = vv + ones(S,1) * mean ; 
plot ( x,posts,plstyle, xsub,t,"@13")
input("demoxot : press return");

		# initialize a random deviation under the posterior
dv = randn(size(x)) * pp  ;
if ( !((verbose <= 1) && (X==2)) )  #  i.e. skip this if X==2 and not very verbose
 vl = bubblexmd( pp , dv , movieS , memory , x , mean,xsub,t ) ;
endif
# immediately show everything we have done
plot ( x,posts,plstyle,x,mean,mstyle, xsub,t,"@13")
if ( verbose ) # show this one sample
	if ( X == 2 ) 
		gset nolabel 5
		gset nolabel 6
endif
endif






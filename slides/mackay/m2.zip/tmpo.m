function tmpo(x,o,t,rmin,rmax,pausetime,memory,data)
# usage 
# demovary2d(x,o,t,rmin,rmax,ptimre,memory,data)
# do a demo using inputs x, etc. - came from demoxot
#  if datainc = 0 then data are left out
#  if datainc = 1 then data are included

verbose = 0 ;
jitter = 1e-4 ;
pausetime=1;
restore25sq;
while(1)
 pausetime 
 s = input("to repeat slower, type factor - ");
 if ( ( s ) ) 
 else break ; endif
 pausetime = pausetime * s ; 
endwhile

gset title "";
ret = 1 ;



function activ ( w ) 

# activ ( w )
#		shows activities of a single neuron with  weight vector w
#               using global data in x,t

	global x ;
	global t ;

	a = x * w  
	y = sigmoid(a) 
	e = t - y   
	d = ( y>0.5 )
	err = ( d != t ) 
	errs = sum(err)
# (d .- e).^2 )

endfunction

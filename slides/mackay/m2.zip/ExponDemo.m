x=[-6:0.1:6];
global A ;
global Ctype ;
global Csymmetry ;
global CO ;
global Calpha ;
global Cbeta ;

Csymmetry=0; CO = 0 ; 
A = 1;  Ctype = 2 ; r = 1.0 ; jitter = 1e-4 ;
C = covALL( x , x , r , jitter ) ;
## unfinished!




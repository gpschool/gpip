function ret = subvector ( t ,  o ) 
# o specifies the columns that were omit. 
 if ((nargin != 2))
    usage ("subvector(t,o)");
  endif
s = size(t) ; 
h = s(2) ; 

v=[];
newl=0;
for l=1:h
	if ( !o(l) ) 
		newl++;
		v(newl) = t(l) ;
	endif
		
endfor
ret = v ;
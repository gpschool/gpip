# usage 
# DEMO2
# runs a sequence of Gaussian process demos
disp("this is unfinished!!!");
#  DJCM August 1997
r=2; 			# default lengthscale 
rmin=0.6;  rmax=3;
rmin2=0.3; rmax2=17;
rmin13=0.2;  rmax13=3;
Amin=0.03 ; Amax=3.4;
S=12;                     # number of samples
SS=50; # number of  samples in 2d plot
SSS=15; # more modest number for lines
movieS=30;                     # number of samples
subL = 10 ; # number of classification generations per sample
varymovieS=10;                     # number of samples
pausetime = 0.3 ;
pausetimeA = 0.1 ;
memory=0.9; 
 lstyle = "-@63" ; # style for prior line samples
 datastyle = "@13" ; # style for data points
global jitter = 1e-6 ;
global A ; 
global Rdjcm = 1 ; # in covR, specifies which covariance construction to use.
#
# define data
#
state = 0 ; State = 18 ;
while (1)
 ans = mymenu("Gaussian process factory",
 "Choose data set",
 "Choose Covariance function",
 "Show movies",
 "quit",
 "Keyboard",
 "quit"
 ) ;
 if ( ans == 0 ) 
	state ++ ; 
	if ( state > State )  # cycle through optinos
		state = 1 ; 
	endif
 else
	state = ans ;
 endif

  randn("seed",0.1243) ; # fix the randomizer
  rand("seed",0.1243);
	initgnu();			# set up graphics
        A = 1 ; 
 counter = 0 ; 
 "O Hagan",
 "symmetries",
 "1/(1+|xi-xj|^2)",
 if(++counter && state==counter)
	substate = 0 ;

	ans = mymenu("Choose data set and sample points",
			"1..6","0.(13).7","0.(35).7","-6..6","quit");
	changexot( ans ) ; 


 elseif(++counter && state==counter)	
  substate = 0 ;
  while (1)
# change the covariance function
        ans = mymenu("change the covariance function",
                        "change core","change r or A","change symmetries / periodicity","change O'Hagan","spatially varying r","quit","keyboard");
        if ( ans == 0 ) 
                substate ++ ;
        else
                substate = ans ;
        endif
        counter = 0 ; 
        if(++counter && substate==counter)
		ans = mymenu("change core","exp( -d^2 )","exp( -|d| )","Cauchy 1/(1+d^2)","_/\_","sinc^2");
		Ctype = ans ; 
        elseif (++counter && substate==counter)
		print "type r=2 and A=1 , etc., then type quit" ;
		keyboard ;
        elseif (++counter && substate==counter)
		ans = mymenu("change symmetries","no symmetries","reflection (crude)","periodic");
		Csymmetry = ans - 1 ; 
                break ;
        elseif (++counter && substate==counter)
                keyboard ;
        else
          break;
        endif
  endwhile
	
 elseif(++counter && state==counter)
	 keyboard;
 else
	break ;
 endif
endwhile

#############################################################

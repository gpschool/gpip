gset size 0.7,0.7 ;
gset noyzeroaxis ;
gset xzeroaxis  ;
gset xrange [0.5:2.5] ;
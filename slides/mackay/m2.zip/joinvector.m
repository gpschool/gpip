function ret = joinvector ( t , tt , o ) 
# o specifies the columns that were omit. If o=1 we pick `t', if 0, `tt'.
# joinvector makes a new vector by combining t and tt
 if ((nargin != 3))
    usage ("joinvector(t,tt,o)");
  endif
s = size(t) ; 
h = s(2) ; 
ss = size(tt) ; 
hh = ss(2) ; 

l=0; ll=0;
for newl=1:(h+hh)
	if ( o(newl) ) 
		l++;
		v(newl) = t(l) ;
	else 
		ll++;
		v(newl) = tt(ll) ;
	endif
		
endfor
ret = v ;
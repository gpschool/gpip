function ret = bubblexM ( M , v , L , alpha , x , indicator ) 
# do a bubble tour of a gaussian 
# making plots versus TWO_DIMENSIONAL x as we go 
 if ((nargin != 6)&&(nargin != 5))
    usage ("bubblexM ( M , v , L , alpha , x [,indicator] )");
  endif

	plainplot = 1 ; 

pointstyle = "@13" ; 
vl=[] ; 	
for l=1:L
	v = alpha * v + sqrt((1.0-alpha^2)) * randn(size(v))*M  ;
	xvtot = [ x' , v' ] ;
	vl(l,:) = [v] ;
	if ( plainplot ) 
	    if ( nargin==6)
gsplot xvtot u 1:2:3 
#		gplot xvtot u 1:2 w linespoints 6 3 , indicator u 1:2 w l 7 8 ;
	    else
gsplot xvtot u 1:2:3 
#		gplot xvtot u 1:2 w linespoints 6 3 ;
	    endif
	else
		plot(x,v,style)
	endif
endfor
ret = vl ;
endfunction

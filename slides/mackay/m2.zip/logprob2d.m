function ret = logprob2d(CI,t)
#
# keyboard
ret = 0.5 * ( log ( det ( CI ) ) - t * CI * t' ) ;

# CCIM.m - makes C, CI, M, etc
	if ( verbose >= 1 ) 
		C = covR( x, x , r , r, jitter )
		input("press return");
	else 
		C = covR( x, x , r , r, jitter ) ;
	endif
# keyboard
	CI=inverse(C);
	M=chol(C);
	vars=diag(C);
	sds=sqrt(vars);

function ret= interpolate(x,t,xtest,r,showdata,jitter,indicator)
# usage 
# demoxot(x,o,t)
# do a demo using inputs x, training data t and desied testlocations xtest.
# returns the evidence. 
# negative showdata sppresses all plots
# showdata = 0 allows plot of curve only
# showdata = 1
# showdata = 2 shows data and pauses then curve

  if (nargin != 5 && nargin != 6 && nargin != 7)
    usage ("")
  endif

verbose = 0 ; 
global A ;
zscore=1;

s=size(x); X=s(2);   # number of training points
s=size(xtest); T=s(2);   # number of test points
if ( verbose ) 
	printf ( "%d training, %d test\n" , X, T ) ;
endif
# S=10;                     # number of samples
# movieS=3;                     # number of samples
#
# Make covariance matrix
#
CCIM ; 
# make off-diagonal bit too.
K = cov2( x , xtest , r , 0 ) ; 
CIt = CI * t' ;
pred = K' *  CIt ;
for  n = 1:T
	kappa(1,n) =  cov2( [xtest(1,n)] , [xtest(1,n)] , r , jitter ) ;
	predvar(n,1) = kappa(1,n) - K(:,n)' * CI * K(:,n) ;
endfor
predsd = sqrt( predvar ) ; 
upper = pred + predsd * zscore ; 
lower = pred - predsd * zscore ; 
xmsd = [ xtest' , pred , predsd ,upper , lower ] ;
xt = [ x' , t' ] ; 
lp = logprob2d ( CI , t ) ; 
if ( showdata > 1 ) 
	if ( nargin >= 7 ) 
		gplot indicator u 1:2 w l 7 7,  xt u 1:2 w p 1 3 ;
	else
		gplot   xt u 1:2 w p 1 3 ;
	endif
	input("interpolate : press return--");
endif
if ( showdata >= 0 ) 
if ( nargin >= 7 ) 
	gplot indicator u 1:2 w l 7 7,  xmsd u 1:5 w l 3 2 , xmsd u 1:4 w l 3 2 , xmsd u 1:2 w l 4 2 , xt u 1:2 w p 1 3 ;
else
	gplot  xmsd u 1:5 w l 3 2 , xmsd u 1:4 w l 3 2 , xmsd u 1:2 w l 4 2 , xt u 1:2 w p 1 4 ;
endif
endif 
# input("interpolate : press return--");
ret = lp ; 

################################################################






function ret = demovary2d(x,o,t,rmin,rmax,pausetime,memory,data,Nr,Ud)
# usage 
# demovary2d(x,o,t,rmin,rmax,ptimre,memory,data)
# do a demo using inputs x, etc. - came from demoxot
#  if datainc = 0 then data are left out
#  if datainc = 1 then data are included
  if (nargin != 6 && nargin != 7 && nargin != 8 && nargin != 9 && nargin != 10)
    usage ("demovaryr(x,o,t,r,S,ptime[,memory[,data[,Nr[,Ud]]]])");
  endif
  if (nargin != 7  && nargin != 8 && nargin != 9 && nargin != 10)
	memory = 0.8 ; 
  endif
  if ( nargin != 8 && nargin != 9 && nargin != 10)
	data = 2 ; 
  endif
  if ( nargin != 9 && nargin != 10)
	Nr=20; # must be 2 or more
  endif
  if (  nargin != 10)
	Ud=4; # number of ups and downs
  endif
verbose = 0 ;
title = 0 ;
jitter = 1e-4 ;
restore25sq;

firsttime=1;
s=size(x); X=s(2);
style="@13";
lstyle = "-@63" ; # style for line samples
mstyle = "-4" ; # style for mean (green lines -14)
dlr = log(rmax/rmin) / ( Nr-1) ; 
dr0 = exp ( dlr ) ;
tt = t ;
logPr = [] ;
gset label 1 "r" at -2.2,-2.2 right

while ( 1 ) 
 r = rmin ; 
 dr = dr0 ;
 for  ud = 1:Ud
     for nr = 1:Nr
	CCIM ;
	indicator = mybox( -2 , r , -2.4 , 0.4 ) ; 
	if ( title )
		command = sprintf ("gset title \"P( y1 , y2 | rho12 = %f )\"", C(1,2));
	    	eval (command);
	else
		gset title "P(y1,y2|r)" ;
	endif
	contourstrue ;

	if ( data == 0 ) 
		gplot indicator u 1:2 w l 7 8 , c1 u 1:2 w l 3 6 , c2 u 1:2 w l 2 7 ;
	else
		plotcontours ;
		if ( firsttime ) 
			lp = logprob2d(CI,t)  ;
			logPr(nr,:) = [ r , C(1,2) , lp , exp(lp) ] ;
		endif
	endif
	pause(pausetime) ; 

	r = r * dr ;
     endfor # nr
     if ( firsttime == 1 ) firstime = 0 ; endif
     dr = 1/dr ;
     r = r * dr ;
 endfor # ud
 s = input("to repeat slower, type factor - ");
 if ( s ) 
 else break ; endif
 pausetime = pausetime * s ; 
endwhile

gset title "";
gset nolabel 1 ;
ret = logPr ;



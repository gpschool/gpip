function ret = covM ( xa , xb , r , jitter )
# make  covariance matrix, not necessarily square, for gaussian process 
# -- this does the Multidimensinoal version.
  if (nargin != 4)
    usage ("cov (xa,xb,r,jitter) - xa,xb is matrix, r is vector (one for each dimesnions)");
  endif
global A ;

	m = size(r) ;
	M = m(2);
	s = size(xa);
	S=s(2); 	s = size(xb);
	Sb=s(2);
	E = zeros(S,Sb)  ;
	for m=1:M ;
		xi = ones(size(xb(m,:)))' * xa(m,:) ;
		xj = xi' ;
		xi = ones(size(xa(m,:)))' * xb(m,:) ;
		dij = xi .- xj ;
	
		D = dij .^ 2 ;
		E = E - D / (2*r(1,m)^2) ;
	endfor

	if ( jitter && (size(xb)==size(xa)) ) 
		ret = A * exp ( E  ) + jitter * eye ( S ) ;
	else
		ret = A * exp ( E )   ;
	endif

endfunction

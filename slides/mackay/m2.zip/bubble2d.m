function ret = bubble2d ( M , v , L , alpha , x , style ) 
# do a bubble tour of a gaussian 
# making plots versus x as we go 
 if ((nargin != 6)&&(nargin != 5))
    usage ("bubblex ( M , v , L , alpha , x [,style] )");
  endif
if (nargin != 6)
# need to fix up style
	style = "-@63" ;
endif
vl=[] ; 	
for l=1:L
	v = alpha * v + sqrt((1.0-alpha^2)) * randn(size(v))*M  ;
	vl(l,:) = [v] ;
	gplot v u 1:2 w p 1 3
#	plot(x,v,"-@63")
endfor
ret = vl ;
endfunction

# This whole thing is a bit pointless -- it shows a dot jumping around
# in 2d.

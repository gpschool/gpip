function demoxotO2(x,o,t,r,rbeta,S,movieS,memory,verbose)
# O Hagan method for extrapolation usage 
# demoxot(x,o,t)
# do a demo using inputs x, etc.
  if (nargin != 9 && nargin != 7 && nargin != 8)
    usage ("demoxotO(x,o,t,r,S,movieS[,memory[,verbose]])");
  endif
  if (nargin != 7  && nargin != 9)
	memory = 0.8 ; 
  endif
  if ( nargin != 9)
	verbose = 1 ; 
  endif

global jitter ;
global alphaO  ; global betaO  ; # set in DEMO.m
showdataalone = 0 ;

s=size(x); X=s(2);
# S=10;                     # number of samples
# movieS=3;                     # number of samples
style="@13";
lstyle  = "-@63" ; # style for line samples
plstyle = "-@53" ; # style for line samples, posterior
mstyle = "-4" ; # style for mean 
#  initgnu();			# set up graphics done elsewhere
#
# Make covariance matrix
#
C=covO2(x,x,r,rbeta,alphaO,betaO,jitter) ;
CIM ; 

# initialize one random sample and do a movie
v=randn(size(x))*M ;
if ( verbose ) # show this one sample
	plot ( x,v,lstyle) ;
	input("demoxotO : one sample : press return");
endif
if ( !((verbose <= 1) && (X==2)) )  #  i.e. skip this if X==2 and not very verbose
 vl = bubblex( M , v , movieS , memory , x ) ;
 input("press return");
endif

# Make S samples and show them - from prior
v=randn(S,X)*M ;
infer();
if ( showdataalone )					
  plot ( x,v,lstyle)
  input("press return");
	plot ( xsub,t,style  ) ; 
	input("demoxotO : press return");
endif

plot ( x,v,lstyle, xsub,t,style) ;
input("demoxotO : press return");

gplot  xmsd u 1:2:3 w error 4 2 , xmean u 1:2 w l 4 2 , xsubt u 1:2 w p 1 3 ;
input("demoxotO : press return--");

# straight away show the samples that go through the data points
# --- make a load of independent samples
vv = randn(S,X) * pp  ;
posts = vv + ones(S,1) * mean ; 
plot ( x,posts,plstyle, xsub,t,"@13")
input("demoxotO : press return");

		# initialize a random deviation under the posterior
dv = randn(size(x)) * pp  ;
if ( !((verbose <= 1) && (X==2)) )  #  i.e. skip this if X==2 and not very verbose
 vl = bubblexmd( pp , dv , movieS , memory , x , mean,xsub,t ) ;
endif
# immediately show everything we have done
plot ( x,posts,plstyle,x,mean,mstyle, xsub,t,"@13")
if ( verbose ) # show this one sample
	if ( X == 2 ) 
		gset nolabel 5
		gset nolabel 6
endif
endif






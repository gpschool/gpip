gplot indicator u 1:2 w l 7 8 , c1 u 1:2 w l 3 6 , c2 u 1:2 w l 2 7 , c3 u 1:2 w l 7 7, c4 u 1:2 w l 5 5 , c5 u 1:2 w l 4 4 , tt u 1:2 w p 1 4 ;

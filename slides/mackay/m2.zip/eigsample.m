# make one realization of all eigs
t = 0; vs=[];
for  k1=1:K
	for  k2=k1:K
		v=randn(size(x))*M ;
		t ++ ;
		vs(t,:) = v ;
	endfor
endfor
HVVS ; 

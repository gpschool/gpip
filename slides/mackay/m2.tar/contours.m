gset size 0.54,0.73 ;
c1 = contour2d ( M, [0,0] , 1.0 , 100 ) ;
c2 = contour2d ( M, [0,0] , 2.0 , 100 ) ; 

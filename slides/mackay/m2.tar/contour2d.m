function ret = contour2d ( M , mean , r , Thetan ) 
# makes a contour of a Gaussian distribution 
# where M is the chol of the covarianc matrix and r is the reqd "radius"

theta = 0.0 ;
dtheta = 2*3.14159 / ( Thetan - 1 ) ; 
list=[];
# make contours
for thetan=1:Thetan
	list(thetan,: ) = mean + r * [cos(theta), sin(theta)] * M ;
  theta = theta + dtheta ;
endfor

ret = list ;

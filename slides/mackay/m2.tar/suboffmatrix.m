function ret = suboffmatrix ( A , o ) 
# o specifies the columns to omit.
# suboffmatrix returns the offdiagonal entries corresponding to the 
# interactions between omitted and non-omitted dudes.
 if ((nargin != 2))
    usage ("suboffmatrix(A,o)");
  endif
s = size(A) ; 
height = s(1) ; width = s(2) ; 
newl=0;
for l=1:height
	if ( o(l) ) 
		newl++;
		newm=0;
		for m =1:width
			if ( !o(m) ) 
				newm++;
				C(newl,newm)=A(l,m);
			endif
		endfor
	endif
		
endfor
ret = C ;
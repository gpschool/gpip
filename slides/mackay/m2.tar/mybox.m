function ret = mybox( xl , xh , yl , height ) 
# for gnuplotting a rectangle
# mybox( xl , xh , yl , height ) 
if ( nargin != 4 )
usage ( "mybox( xl , width , yl , height ) \n" ) 
endif
 ret = [ xl , yl ; xl , yl+height ; xl+xh , yl+height ; xl+xh , yl ; xl , yl ] ;

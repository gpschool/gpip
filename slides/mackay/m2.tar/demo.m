# usage 
# demo()
x=[1,2,3,4,5,6] ;
s=size(x); X=s(2);
S=10;                     # number of samples
movieS=3;                     # number of samples
style="@13";
initgnu();			# set up graphics
#
# Make covariance matrix
#
C = cov( x , 2 ) ;
CI=inverse(C);
M=chol(C);
# initialize one random sample and do a movie
v=randn(size(x))*M ;
vl = bubblex( M , v , movieS , 0.8 , x ) ;
#  vl' * vl / 1000.0 
#
# Make S samples and show them
v=randn(S,X)*M ;
plot ( x,v,"-1")
#
# define data
#
o=[1,1,0,0,0,1] ;
t=[1,1.25,0.1] ;

# noto , xsub , CIsub , CIsubM , postCov , mean , postcovM , pp
# are obtained from x,o,CI,t
infer();
					# show the data
plot ( xsub,t,style  ) ; 
pause(1);
plot ( x,v,"-1", xsub,t,style) ;

# straight away show the samples that go through the data points
# --- make a load of independent samples
vv = randn(S,X) * pp  ;
posts = vv + ones(S,1) * mean ; 
plot ( x,posts,"-1", xsub,t,"@13")
#
# show a movie of posterior samples.
# vl = bubblexm( pp , vv , movieS , 0.8 , x , mean ) ;

		# initialize a random deviation under the posterior
dv = randn(size(x)) * pp  ;
vl = bubblexmd( pp , dv , movieS , 0.8 , x , mean,xsub,t ) ;

#
# define data
#
o=noto ;
t=[-1,-1.25,-0.1] ;

# noto , xsub , CIsub , CIsubM , postCov , mean , postcovM , pp
# are obtained from x,o,CI,t
infer();
					# show the data
plot ( xsub,t,style  ) ; 
pause(1);
plot ( x,v,"-1", xsub,t,style) ;

# straight away show the samples that go through the data points
# --- make a load of independent samples
vv = randn(S,X) * pp  ;
posts = vv + ones(S,1) * mean ; 
plot ( x,posts,"-1", xsub,t,"@13")
#
# show a movie of posterior samples.
# vl = bubblexm( pp , vv , movieS , 0.8 , x , mean ) ;

		# initialize a random deviation under the posterior
dv = randn(size(x)) * pp  ;
vl = bubblexmd( pp , dv , movieS , 0.8 , x , mean,xsub,t ) ;

# show the indep samples again
plot ( x,posts,"-1", xsub,t,"@13")



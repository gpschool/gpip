gset size 0.54,0.73

rrrr = ( -log( det(C) ) + 4.0 ) ;  
if ( rrrr > 0 ) 
	rrr = sqrt(rrrr) ;
	c1 = contour2d ( M, [0,0] , rrr , 100 ) ;
else
	c1 = [5,5] ;
endif
rrrr = ( -log( det(C) ) + 1.0 ) ;  
if ( rrrr > 0 ) 
	rrr = sqrt(rrrr) ;
	c2 = contour2d ( M, [0,0] , rrr , 100 ) ;
else
	c2 = [5,5] ;
endif
rrrr = ( -log( det(C) ) - 2.0 ) ;  
if ( rrrr > 0 ) 
	rrr = sqrt(rrrr) ;
	c3 = contour2d ( M, [0,0] , rrr , 100 ) ;
else
	c3 = [5,5] ;
endif
rrrr = ( -log( det(C) ) - 5.0 ) ;  
if ( rrrr > 0 ) 
	rrr = sqrt(rrrr) ;
	c4 = contour2d ( M, [0,0] , rrr , 100 ) ;
else
	c4 = [5,5] ;
endif
rrrr = ( -log( det(C) ) - 8.0 ) ;  
if ( rrrr > 0 ) 
	rrr = sqrt(rrrr) ;
	c5 = contour2d ( M, [0,0] , rrr , 100 ) ;
else
	c5 = [5,5] ;
endif

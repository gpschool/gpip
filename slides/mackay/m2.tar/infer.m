# noto , xsub , CIsub , CIsubM , postCov , mean , postcovM , pp , pvars, psds
# are obtained from x,o,CI,t
noto = 1 - o ;
xtest = subvector( x , o ) ;
xsub = subvector( x , noto ) ;
CIsub = submatrix ( CI,o ) ;
CIsubM = suboffmatrix ( CI,o ) ;
postCov = inverse( CIsub ) ;
tmp= - postCov * CIsubM' * t' ; # posterior means at unmeasured locns.
postCovM = chol(postCov) ;
# get point by point variance vector
pvars=diag(postCov);
psds=sqrt(pvars);
# make alternative matrices, expanded up to the whole vector. 
pp = unsubmatrix( postCovM , o ) ;
mean = joinvector( t , tmp' , o )' ; 
# these guys are not used in the first 6 demos
Csub = submatrix ( C,noto ) ;
CsubI = inverse ( Csub ) ;
#
# keyboard
msd = [ tmp , psds ] ; # 
xmsd = [ xtest , tmp , psds ] ; # 
xsubt = [ xsub , t' ] ; 
xmean = [ x' , mean' ] ; 


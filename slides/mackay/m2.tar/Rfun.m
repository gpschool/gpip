function ret = Rfun ( x ) 
# ret = 2.0 * exp ( - 2.5 * exp( - 3.0 * ( x .- 2.0 ).^2 ) ) ;
ret = 2.0 * exp ( - 2.5 * exp( - 3.0 * ( x .- 2.0 ).^2 )+  2.5 * exp( - 3.0 * ( x .- 4.0 ).^2 ) ) ;

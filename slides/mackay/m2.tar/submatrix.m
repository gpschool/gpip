function ret = submatrix ( A , o ) 
# o specifies the columns to omit.
 if ((nargin != 2))
    usage ("submatrix(A,o)");
  endif
s = size(A) ; 
height = s(1) ; width = s(2) ; 
newl=0;
for l=1:height
	if ( !o(l) ) 
		newl++;
		newm=0;
		for m =1:width
			if ( !o(m) ) 
				newm++;
				C(newl,newm)=A(l,m);
			endif
		endfor
	endif
		
endfor
ret = C ;
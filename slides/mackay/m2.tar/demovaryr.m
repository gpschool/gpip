function demovaryr(x,o,t,rmin,rmax,movieS,memory,data)
# usage 
# demovaryr(x,o,t,rmin,rmax,movieS,memory,data)
# do a demo using inputs x, etc. - came from demoxot
#  if datainc = 0 then data are left out
#  if datainc = 1 then data are included
  if (nargin != 6 && nargin != 7 && nargin != 8)
    usage ("demovaryr(x,o,t,r,S,movieS[,memory[,data]])");
  endif
  if (nargin != 7  && nargin != 8)
	memory = 0.8 ; 
  endif
  if ( nargin != 8)
	data = 2 ; 
  endif
verbose = 0 ;
jitter = 1e-4 ;

# o=[1,1,0,0,0,1] ;
# t=[1,1.25,0.1] ;
firsttime=1;
s=size(x); X=s(2);
style="@14";
lstyle = "-@64" ; # style for line samples
mstyle = "-4" ; # style for mean (green lines -14)
Nr=5; # must be 2 or more
Ud=3; # number of ups and downs
dlr = log(rmax/rmin) / ( Nr-1) ; 
dr0 = exp ( dlr ) ;

while ( 1 ) 

r = rmin ; 
dr = dr0 ;
for  ud = 1:Ud
	purge_tmp_files ;
for nr = 1:Nr
	command = sprintf ("gset title \"r = %f\"", r);
    	eval (command);
	r
	CCIM ;
	if ( data == 0 ) 
		v=randn(size(x))*M ;
		vl = bubblex( M , v , movieS , memory , x ) ;
	else
		infer ;

		if(firsttime) 
			plot ( xsub,t,style  ) ; 
			input("press return");
			firsttime = 0 ; 
		endif

		msd = [ tmp , psds ] ; # 
		xmsd = [ xtest , tmp , psds ] ; # 
		xsubt = [ xsub , t' ] ; 
		xmean = [ x' , mean' ] ; 

		dv = randn(size(x)) * pp  ;
		vl = bubblexmd( pp , dv , movieS , memory , x , mean,xsub,t ) ;
	endif

	r = r * dr ;
endfor # nr
dr = 1/dr ;
r = r * dr ;

endfor # ud

s = input("to repeat, type 1");
if ( s != 1 ) break ; endif
endwhile

gset title ""




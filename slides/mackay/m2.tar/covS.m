function ret = covS ( xa , xb , r , jitter )
# make  covariance matrix, not necessarily square, for gaussian process 
# S -- with symmetry property.
  if (nargin != 4)
    usage ("covS (xa,xb,r,jitter) - xa,xb is vector, r is scalar");
  endif
global A ;

	s = size(xa);
	S=s(2);	
	xi = ones(size(xb))' * xa ;
	xj = xi' ;
	xi = ones(size(xa))' * xb ;
	dij = xi .- xj ;
	
	D = dij .^ 2 ;
	dij2 = xi .+ xj ;
	
	D2 = dij2 .^ 2 ;
	ret = A *  ( exp ( - D / (2*r^2)) + exp ( - D2 / (2*r^2) ));
	if ( jitter && (size(xb)==size(xa)) ) 
		ret = ret +  jitter * eye ( S )  ;
	else
	endif

endfunction

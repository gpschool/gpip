function ret = bubblexmd ( M , v , L , alpha , x , mean , dx,dt,indicator ) 
# do a bubble tour of a gaussian 
# making plots versus x as we go 
# includes a mean vector 
# and data too
 if ((nargin != 8)&&(nargin != 9))
    usage ("bubblex ( M , v , L , alpha , x , m ,dx,dt[,indicator-box] )");
  endif

	plainplot = 1 ; 
	style = "-@63" ; # unused

if ( plainplot )
	dxt = [ dx , dt' ] ; 
endif
pointstyle = "@13" ; 
vl=[] ; 	
for l=1:L
	v = alpha * v + sqrt((1.0-alpha^2)) * randn(size(v))*M  ;
	vtot = v + mean ;
	xvtot = [ x' , vtot' ] ;
	vl(l,:) = [vtot] ;
	if ( plainplot ) 
            if ( nargin == 9 ) 
		gplot xvtot u 1:2 w linespoints 5 4 , dxt u 1:2 w p 1 4 , indicator u 1:2 w l 7 8 ;
	    else
		gplot xvtot u 1:2 w linespoints 5 4 , dxt u 1:2 w p 1 4 ;
	    endif
	else
		plot(x,vtot,style,dx,dt,pointstyle) ;
	endif
endfor
ret = vl ;
endfunction

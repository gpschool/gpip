# usage 
# DEMO
# runs a sequence of Gaussian process demos
#  DJCM August 1997
more off
printf "This DEMO works fine with octave-2.0 and did not work with 2.1.33"
global sigmoids ;
sigmoids = 0 ; 
K=7 ; # number of eigenvalues 
rmin=0.6;  rmax=3;
rmin2=0.3; rmax2=17;
rmin13=0.27;  rmax13=5;
Amin=0.03 ; Amax=3.4;

S=12;                     # number of samples
SS=50; # number of  samples in 2d plot
SSS=15; # more modest number for lines
movieS=300;                     # number of samples in a movie
subL = 4 ; # number of classification generations per sample
varymovieS=100;                     # number of samples per frame of
				# longer multi-segment movies
pausetime = 0.3 ;
pausetimeA = 0.1 ;
memory=0.98; ## standard memory value
				# persistence during movies
memorymesh=0.99; ## memory for mesh movies
eigmemory=0.99; 
 lstyle = "-@64" ; # style for prior line samples
 datastyle = "@14" ; # style for data points
r=2; 			# default lengthscale 
 gset pointsize 2 ;
global jitter = 1e-6 ;
global standard = 1 ; 
global A ; 
global Rdjcm = 1 ; # in covR, specifies which covariance construction to
		   # use.
higherx = [0, 0.5, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.2, \
	   3.4, 3.6, 3.8, \
	   4,  4.2, 4.4, 4.6, 4.8, 5, 5.25, 5.5, 5.75, 6 , 6.5, 7] ;
highero=[0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0] ;
## size(higherx) size(highero)
#
# define data
#
state = 0 ; State = 48 ;
while (1)
	printf ("standard = %d  ; " , standard ) ; 
	printf ("state =  %d  ;" , state ) ; 
	printf ("r = %f\n" , r ) ; 
 ans = mymenu("Gaussian distribution",
 "2-d(in 2d)",
 "2-d",
 "6-d" ,
 "6-d matrix again",
 "27-d",
 "27-d(varying r), bubble",
# "27, varying r, mean",
 "2-d, varying r, logPr",
 "27-d, varying r, mean, logPr",
# "27-d, varying r, bubble, logPr",
 "2-d / 6-d, varying A, logPr",
# "6-d, varying A, bubble, logPr",
 "interpolation assuming noise",
 "Two dimensional input space",
 "bubble classifier",
 "quit",
 "efficient interpolant",
 "spatially varying lengthscale r(x)",
 "O Hagan extrapolation method",
 "symmetries",
 "1/(1+|xi-xj|^2)",
 "toggle between standard model and linear regression",
 "change r",
 "change K (num eigs)",
 "eigenvalue model K(def=7)",
 "eigenvalue model 2",
 "eigenvalue model 3",
# "2-dimensional input space",
 "keyboard",
 "quit"
 ) ;
 if ( ans == 0 ) 
	state ++ ; 
	if ( state > State )  # cycle through optinos
		state = 1 ; 
	endif
 else
	state = ans ;
 endif
	purge_tmp_files ;

  randn("seed",0.1243) ; # fix the randomizer
  rand("seed",0.1243);
	initgnu();			# set up graphics
        A = 1 ; 
r=2; 			# default lengthscale 
 counter = 0 ; 
 purge_tmp_files ;
 if(++counter && state==counter)
# 1 "Two dimensional Gaussian distribution"
#      system("gnuplot -persist -geometry 50x50+100+30  gnu/key gnu/key4g2") ;
  x=[1,2] ;  o=[1,0] ;  t=[1] ;
  substate = 1 ; 
  while (1)
	counter = 0 ; 
	if(++counter && substate==counter)
	  demo2d(x,o,t,r,SS,movieS,0,1); # 0 for no memory
	elseif (++counter && substate==counter)
	  demo2d(x,o,t,r/3,SS,movieS,0,1); 
	elseif ( ++counter && substate==counter)
	  demo2d(x,o,t,r*3,SS,movieS,0,1); # 0 for no memory
	else
	  break;
	endif
	ans = mymenu("Two dimensional Gaussian distribution",
			"r","r/3","r*3","quit");
	if ( ans == 0 ) 
		substate ++ ;
	else
		substate = ans ;
	endif
  endwhile

 elseif(++counter && state==counter)
# 2 "Two dimensional Gaussian distribution"
#      system("gnuplot -persist -geometry 50x50+100+30  gnu/key gnu/key4g2all") ;
  x=[1,2] ;  o=[1,0] ;  t=[1] ;
  restore525;
  demoxot(x,o,t,r,SSS,movieS,memory,2); # 0 for no memory , 1/2 for verbose,ver verbose

 elseif(++counter && state==counter)
# 3 ("Six dimensional Gaussian distribution","s") ;
##      system("gnuplot -persist -geometry 50x50+100+30  gnu/key gnu/key4g2all") ;
  x=[1,2,3,4,5,6] ;
  o=[1,1,0,0,0,1] ;
  t=[1,1.25,0.1] ;
  demoxot(x,o,t,r,S,movieS,memory,1);

 elseif(++counter && state==counter)
# 4 ("Six dimensional Gaussian distribution again (for revelation purposes)
  x=[1,2,3,4,5,6] ;
  verbose = 1 ; 
 CCIM;
 s=size(x); X=s(2);
 v=randn(S,X)*M ;
 plot ( x,v,lstyle)
 input("press return");

 elseif(++counter && state==counter)
				# 5 ("27 dimensional Gaussian
				# distribution","s") ;  increased
				# dimensions Mon 5/6/06
   x=higherx; ## defined above
   gset xrange [-0.5:7.5] ;
   o=highero; ## defined above 
  t=[-1,-1.25,-0.1] ;
  demoxot(x,o,t,r,S,movieS,memory,0);

 elseif(++counter && state==counter)
# 6 ("27 dimensional Gaussian distribution - vary r
  x=higherx;
  gset xrange [-0.5:7.5] ;
  gset xrange [-0.5:7.5] ;
  o=highero;
  t=[-1,-1.25,-0.1] ;
#  demovaryr(x,o,t,rmin,rmax,varymovieS,memory,0);
#  demovaryr(x,o,t,rmin,rmax,varymovieS,memory,1);
  logPr = demovaryrP(x,o,t,rmin13,rmax13,varymovieS,memory,0,7,2);
  logPr = demovaryrP(x,o,t,rmin13,rmax13,varymovieS,memory,1,7,2);

# elseif(++counter && state==counter)
# 7 13 dimensional Gaussian distribution - vary r and plot logPr, showing the mean
#  x=[0, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6 , 7] ;
#  gset xrange [-0.5:7.5] ;
#  o=[0,0,0,0,0,1,0,1,0,1,0,0,0] ;
#  t=[-1,-1.25,-0.1] ;
#  logPr = demovaryrP(x,o,t,rmin13,rmax13,-1,memory,1,16,3);
##! don't  plotlogPr ;

 elseif(++counter && state==counter)
# 7 ("2 dimensional Gaussian distribution - vary r
  x=[ 1, 2] ;  o=[1,1];  t=[0.9,0.56] ;
  gset xrange [-0.5:6.5] ;	
	plot ( x , t , datastyle ) ; 
#   input ( "DEMO : press return");
#  x=[0, 1, 2,3,4,5,6] ;  o=[0,1,1,0,0,0,0];  t=[0.9,0.56] ;
#  logPr = demovaryrP(x,o,t,rmin2,rmax2,-1,memory,1);
#  logPr = demovaryrP(x,o,t,rmin2,rmax2,5,memory,1);

  input ( "DEMO : press return");
  x=[ 1, 2] ;  o=[1,1];  t=[0.9,0.56] ;
  logPr = demovary2d(x,o,t,rmin2,rmax2,pausetime,memory,1,100,2);
  plotlogPr ;

 elseif(++counter && state==counter)
# 8 13 dimensional Gaussian distribution - vary r and plot logPr (MEAN)
  x=higherx;##[0, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6 , 7] ;
  gset xrange [-0.5:7.5] ;
  o=highero;##[0,0,0,0,0,1,0,1,0,1,0,0,0] ;
  t=[-1,-1.25,-0.1] ;
  logPr = demovaryrP(x,o,t,rmin13,rmax13,-1,memory,1,45,2);
  plotlogPr ;
	initgnu();			# set up graphics
  gset xrange [-0.5:7.5] ;
  input ( "DEMO : press return");
  logPr = demovaryrP(x,o,t,rmin13,1.0,-1,memory,1,9*45/14.0,1,0);

# elseif(++counter && state==counter)
##("13 dimensional Gaussian distribution - vary r and plot logPr (CUCCLE)
#  x=[0, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6 , 7] ;
#  gset xrange [-0.5:7.5] ;
#  o=[0,0,0,0,0,1,0,1,0,1,0,0,0] ;
#  t=[-1,-1.25,-0.1] ;
#  logPr = demovaryrP(x,o,t,rmin13,rmax13,varymovieS,memory,1);
#  plotlogPr ;

 elseif(++counter && state==counter)
#("2 dimensional Gaussian distribution - vary A
  input("setting A ");
  gset xrange [-1:6.5] ;	
  x=[ 1, 2] ;  o=[1,1];  t=[0.9,0.56] ;
	plot ( x , t , datastyle ) ; 
  input ("press return") ;
  x=[0, 1, 2,3,4,5,6] ;  o=[0,1,1,0,0,0,0];  t=[0.9,0.56] ;
  logPr = demovaryAP(x,o,t,r,Amin,Amax,5,memory,1,45,2);
#  input ("press return") ;
  x=[ 1, 2] ;  o=[1,1];  t=[0.9,0.56] ;
  logPr = demovary2dA(x,t,r,Amin,Amax,pausetimeA,memory,1,100,2);
  plotlogPA ;

# elseif(++counter && state==counter)
## ## # ("6 dimensional Gaussian distribution - vary A
#  x=[0, 1, 2,3,4,5,6] ;  o=[0,1,1,0,0,0,0];  t=[0.9,0.56] ;
#  logPr = demovaryAP(x,o,t,r,Amin,Amax,-1,memory,1);
## ## #  logPr = demovaryAP(x,o,t,r,Amin,Amax,5,memory,1);
## ## #  plotlogPA ;


 elseif(++counter && state==counter)
				# noisy interpolation  -- inferring sigma
  sigmafun;

 elseif(++counter && state==counter)
# two dimensions  using the mesh command. 
#  x=[0, 1, 2, 0 ,1,2 , 0 ,1,2 , 0 ,1,2 ; 0,0,0,1,1,1,2,2,2 ,3,3,3 ] ;
  o=[0,0,0, 0,0,0, 0,0,0, 0,0,1];
  t=[-0.1] ;
  rm = [1,1]; # multidimensional lengthscales
  twodrange = 3.0 ; nmesh = 27 ;
  com = sprintf (" gset xrange [-%f:%f];   gset yrange [-%f:%f];",twodrange,twodrange,twodrange,twodrange ) ;
  eval (com ) ; 
  x1 = x2 = linspace (-twodrange, twodrange, nmesh )';
  gset zrange [-2.685:2.685] ;
 gset ztics -4,1,4 ;
 gset xtics -12,1,12 ;
 gset ytics -12,1,12 ;
 gset noxzeroaxis ; gset border 255 ls 8
  demoxotMmesh(x1,x2,o,t,rm,2,120,memorymesh,0);

  input "next, unequal lengthscales (3,1)" ;
  rm = [3,1]; # multidimensional lengthscales
  demoxotMmesh(x1,x2,o,t,rm,2,52,memorymesh,0);

  input "next, unequal lengthscales (1,3)" ;
  rm = [1,3]; # multidimensional lengthscales
  demoxotMmesh(x1,x2,o,t,rm,2,52,memorymesh,0);
  gset noparametric
				#  xtics alone not sufficient 
  gset xtics  autofreq ; gset ytics autofreq ; gset ztics autofreq ;

 elseif(++counter && state==counter)
# bubble classifier
#  x=[0, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6 , 7] ;
#  x=higherx;
   x=[0:0.2:7];
  gset xrange [-0.5:7.7] ;
  verbose = 0 ;
  A = 2.1 ; ## crank up amplitude a little!
  r=1.5; 			# reduce default lengthscale 
  CCIM;          
  s=size(x); X=s(2);
  randn("seed",0.1243) ; 
  rand("seed",0.1243);
  v=randn(1,X)*M ;
  bubblepoints = 115 ; ## number of big loops ; subL is number of
  ## subloops (10)
  bubbleC( M , v , bubblepoints , memory , x , subL , 1 ) ; 

 elseif(++counter && state==counter)
	break;

 elseif(++counter && state==counter)
# elegant interpolant  using efficient formula
  x=[ 3, 4, 5] ;  t=[-1,-1.25,-0.1] ;
  gset xrange [-0.5:7.5] ;
  xtest=[0:70]/10.0 ;
  interpolate(x,t,xtest, r,1,jitter) ;	

 elseif(++counter && state==counter)
# spatially varying r 
  x=[0:35]/5.0 ;
 o=zeros(size(x));
 o(1,7)=1; o(1,17)=1; o(1,12)=1;
  t=[-1,-1.25,-0.1] ;

  R=Rfun(x) ;
  gset autoscale xy;
  plot (x,R,"-");
  input"assumed lengthscale - press return";
  substate = 1 ; 
	initgnu();			# set up graphics
  gset xrange [-0.5:7.5] ;
  while (1)
	counter = 0 ; 
	if(++counter && substate==counter)
		Rdjcm = 1 ; # djcm style
	  	demoxotR(x,o,t,R,S,movieS,memory,0);
	elseif (++counter && substate==counter)
		Rdjcm = 2 ; # djcm style, unifomr varinace
  		demoxotR(x,o,t,R,S,movieS,memory,0);
	elseif ( ++counter && substate==counter)
		Rdjcm = 0 ; # mng style
  		demoxotR(x,o,t,R,S,movieS,memory,0);
	else
	  break;
	endif
	ans = mymenu("spatially varying r",
			"djcm style","uniform vertical variance","mng","quit");
	if ( ans == 0 ) 
		substate ++ ;
	else
		substate = ans ;
	endif
  endwhile

 elseif(++counter && state==counter)
# o hagan extrapolation method
  x=[0:35]/5.0 ;
  o=zeros(size(x));
  o(1,7)=1; o(1,17)=1; o(1,12)=1;
  t=[-1,-1.25,-0.1] ;
	initgnu();			# set up graphics
gset xrange [-0.1:7.1] ;
 global alphaO = 0.25 ; global betaO = 0.25 ;
  substate =0 ; 
  while (1)
	ans = mymenu("O Hagan extrapolation scheme",
			"r=0.5, both","r=2,both","ra=0.5, rb=3","comparative demo of standard model with varying r.","quit");
	if ( ans == 0 ) 
		substate ++ ;
	else
		substate = ans ;
	endif
	counter = 0 ; 
	if(++counter && substate==counter)
#	elseif (++counter && substate==counter)
 		r=0.5;
  		demoxotO(x,o,t,r,S,movieS,memory,0);
	elseif ( ++counter && substate==counter)
 		r=2.0;
  		demoxotO(x,o,t,r,S,movieS,memory,0);
	elseif ( ++counter && substate==counter)
		 r=0.5; rbeta=3.0 ;
  		demoxotO2(x,o,t,r,rbeta,S,movieS,memory,0);
	elseif ( ++counter && substate==counter)
  		logPr = demovaryrP(x,o,t,rmin13,rmax13,-1,memory,1,14,2);
	else
	  break;
	endif

  endwhile
# 

 elseif(++counter && state==counter)
# symmetries
#  x=[-6,-5,-4,-3,-2,-1,-0.5,0,0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6 , 17] ;
  x=[-6,-5,-4,-3,-2,-1,-0.5,0,0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6 , 7] ;
  o=[0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,0] ;
  t=[-1,-1.25,-0.1] ;

#  o=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1] ;
#  t=[0.0] ;

 gset ytics
  gset xrange [-7.5:7.5] ;
  demoxotS(x,o,t,r,S,movieS,memory,0);

 elseif(++counter && state==counter)
#  1/1+dx^2
  x=[0:35]/5.0 ;
  o=zeros(size(x));
  o(1,7)=1; o(1,17)=1; o(1,12)=1;
  t=[-1,-1.25,-0.1] ;

 gset ytics
  gset xrange [-0.5:7.5] ;
  demoxotC(x,o,t,r,S,movieS,memory,0);

 elseif(++counter && state==counter)
#
	standard = 1 - standard ; # flips
	printf ("standard = %d\n" , standard ) ; 

 elseif(++counter && state==counter)
	r = input("new value for r - ");
	printf ("r = %f\n" , r ) ; 

 elseif(++counter && state==counter)
	K = input("new value for K (num eigs) - ");

 elseif(++counter && state==counter)
				# make matrix whose entries are GP samples .
				# Memory was 0.9, but 0.99 makes better demo on coll and yell
	x=[1:0.1:6];	
	GPeigs(x,r,S,movieS,eigmemory,0,K);

 elseif(++counter && state==counter)
# make matrix whose entries are GP samples
	x=[1:0.1:6];	
	GPeigs(x,r,S,4*movieS,eigmemory,0,2);

 elseif(++counter && state==counter)
# make matrix whose entries are GP samples
	x=[1:0.1:6];	
	GPeigs(x,r,S,4*movieS,eigmemory,0,3);

# elseif(++counter && state==counter)
## two dimensions of input space.
#  x=[0, 1, 2,3,4,5,  5,4,3, 2,1,0 , 0 ,1,2,3,4,5,5,4,3 ,2,1, 0 ; 0, 0,0,0,0,0,1,1,1,1,1,1,2,2,2 ,2,2,2,3,3,3,3,3,3 ] ;
#  o=[0,0,0, 0,0,0, 0,0,0, 0,0,1];
#  t=[-0.1] ;
#  rm = [1,1]; # multidimensional lengthscales
#
#  gset xrange [-.5:5.5] ;
#  gset yrange [-.5:5.5] ;
#  gset zrange [-1:3] ;
#  gset parametric ;
#  demoxotM(x,o,t,rm,2,20,memory,0);
#  input "next, a longer lengthscale" ;
#  rm = [2,2]; # multidimensional lengthscales
#  demoxotM(x,o,t,rm,2,20,memory,0);

 elseif(++counter && state==counter)
	 keyboard;
 else
	break ;
 endif
endwhile

#############################################################

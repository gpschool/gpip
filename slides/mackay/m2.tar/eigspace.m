# eigspace
# a little program to find random eigenvalue spectra and spacings
verbose = 0 ; 
Nlo = 5 ;
Nhi = 205 ;
dN = 20 ;

N = Nlo ; k=1;
H=[] ;
while ( N <= Nhi )

	K = N ; 	
	t = 0; vs=[];
	for  k1=1:K
		for  k2=k1:K
			H(k1,k2)=randn() ;
			if ( k2 > k1 ) 
				H(k2,k1) = H(k1,k2) ;
			endif	
		endfor
	endfor
	
	com1 = sprintf("V%d = [  sort(eig(H)) , [1:K]' ] ; \n", N );
	com2 = sprintf("V%d  t '%d' u 1:2 w l", N , N  );
	if ( k == 1 )
		coms = sprintf("gplot %s",com2);
	else
		coms = sprintf("%s, %s",coms,com2);
	endif
# sq = [ 2.0 * sqrt([1:205]') , [1:205]' ] ;
# , sq t 'sqrt' u 1:2 w l
# this is a perfect fit for lambdamax
	if ( verbose >= 3 )
		printf ( "%s\n" , com1) ;
		printf ( "%s\n" , com2) ;
		printf ( "%s\n" , coms) ;
		keyboard ; 
	endif
	eval(com1);
	eval(coms);
	if   ( verbose >= 1 ) input ( "press return" ) ; 	
	endif

	N = N + dN ; 	 k++ ;

endwhile

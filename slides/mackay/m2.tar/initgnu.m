gset nokey
gset size 0.7,0.7
gset nologscale xy
gset xrange [0.5:6.5]
gset clip one
gset yrange [-2.5:2.5]
gset noyzeroaxis
gset xzeroaxis
gset title ""
gset label 1 
gset nolabel 1

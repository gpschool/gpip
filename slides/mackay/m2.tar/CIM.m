# CIM.m -  CI, M, etc
# c.f. CCIM which used to have make C and CI and M
# here it is separate because there are many ways to make a C.
	CI=inverse(C);
	M=chol(C);
	vars=diag(C);
	sds=sqrt(vars);

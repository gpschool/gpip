function demoxotM(x,o,t,r,S,movieS,memory,verbose)
# usage 
#
#  demoxotM(x,o,t,r,S,movieS,memory,verbose)
#
# x is a M * N matrix where M is the dimension of the space
# and N is the number of data points.
# o is a N vector
# so is t
# r is a vector of length M
# do a demo using inputs x, etc.
#
  if (nargin != 6 && nargin != 7 && nargin != 8)
    usage ("demoxot(x,o,t,r,S,movieS[,memory[,verbose]])");
  endif
  if (nargin != 7  && nargin != 8)
	memory = 0.8 ; 
  endif
  if ( nargin != 8)
	verbose = 1 ; 
  endif

# S                     # number of samples
# movieS                # number of samples
global jitter ;
# jitter = 1e-4 ;
showdataalone = 0 ;

s=size(x); X=s(2);
#  initgnu();			# set up graphics done elsewhere
#
# Make covariance matrix
#
	if ( verbose >= 1 ) 
		C = covM( x, x , r , jitter )
		input("press return");
	else 
C = covM( x, x , r , jitter ) ;
	endif
CIM ; 

# initialize one random sample and do a movie
v=randn(1,X)*M ;

xvtot = [x',v'] ;
gsplot xvtot u 1:2:3 

mean = zeros ( size(x) ) ; 
 bubblexM( M , v , movieS , 0.8 , x ) ;




function wret = learn ( w , L ) 

# learning for single neuron classifier 
# I don't understand why this is invisible

	global x ;
	global t ;
	disp (" enter learn ")
	for l = 1:L
		a = x * w  ;
		y = sigmoid(a) ;
		e = t - y 
		gw = x' * e ;
		w = w + eta * gw  ;
	endfor
	wret = w 
endfunction

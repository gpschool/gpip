# CCIM.m - makes C, CI, M, etc
	if ( verbose >= 1 ) 
		C = cov2( x, x , r , jitter )
		input("C is the covariance matrix 'K' - press return");
	else 
		C = cov2( x, x , r , jitter ) ;
	endif
	CI=inverse(C);
	M=chol(C);
	vars=diag(C);
	sds=sqrt(vars);

function ret = covsigmoid ( xa , xb , r , varbias ,  jitter )
# make  covariance matrix, not necessarily square, for gaussian process
				# using the sigmoidal covariance function
  if (nargin != 5)
    usage ("cov (xa,xb,r, varbias ,jitter) - xa,xb is vector, r is scalar");
  endif
global A ;

	s = size(xa);
	S=s(2);	
	xi = ones(size(xb))' * xa ;
	xj = xi' ;
	xi = ones(size(xa))' * xb ;
	dij = varbias + xi .* xj ;
	
	D = dij / (r^2) ;
	if ( jitter && (size(xb)==size(xa)) ) 
	  ret = A *(2.0/3.141592) * asin ( (D) ./ sqrt((1+(varbias+xi.*xi)/r^2 ).*((1+(varbias+xj.*xj)/r^2)) ) )   + jitter * eye ( S )  ;
	else
	  ret = A *(2.0/3.141592) * asin ( (1.0 + D) / sqrt((2+xi.*xi/r^2 ).*(2+xj.*xj/r^2)) ) ;
	endif

endfunction



# make one realization of all eigs
t = 0; 
alpha = memory ; salpha = sqrt((1.0-alpha^2)) ;
for  k1=1:K
	for  k2=k1:K
		v=randn(size(x))*M ;
		t ++ ;
		vs(t,:) = alpha * vs(t,:) + salpha * v  ;
	endfor
endfor
HVVS ; 

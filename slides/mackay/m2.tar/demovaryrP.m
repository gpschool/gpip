function ret= demovaryrP(x,o,t,rmin,rmax,movieS,memory,data,Nr,Ud,firsttime)
# usage 
# demovaryrP(x,o,t,rmin,rmax,movieS,memory,data,Nr,Ud)
# do a demo using inputs x, etc. - came from demoxot
#  if datainc = 0 then data are left out
#  if datainc = 1 then data are included
# works out logP along the way.
# only makes sense if data=1
  if (nargin != 6 && nargin != 7 && nargin != 8 && nargin != 9 && nargin != 10 && nargin != 11)
    usage ("demovaryrP(x,o,t,r,S,movieS[,memory[,data[,Nr[,Ud]]]])");
  endif
  if (nargin != 7  && nargin != 8 && nargin != 9 && nargin != 10 && nargin != 11)
	memory = 0.8 ; 
  endif
  if ( nargin != 8 && nargin != 9 && nargin != 10 &&  nargin != 11)
	data = 2 ; 
  endif
  if ( nargin != 9 && nargin != 10 && nargin != 11)
	Nr=15; # must be 2 or more
  endif
  if ( nargin != 10 &&  nargin != 11)
	Ud=3; # number of ups and downs
  endif
  if (  nargin != 11)
	firsttime=1; # number of ups and downs
  endif
title = 0 ; # whether to show title
verbose = 0 ;
jitter = 1e-4 ;
global sigmoids ;

pausetime=0.02;
s=size(x); X=s(2);
style="@14";
lstyle = "-@64" ; # style for line samples
plstyle = "-@54" ; # style for line samples, posterior
mstyle = "-4" ; # style for mean (green lines -14)
dlr = log(rmax/rmin) / ( Nr-1) ; 
dr0 = exp ( dlr ) ;
firstrun = 1 ; 
logPr = [] ;
gset label 1 "r" at -0.1,-1.8 right

while ( 1 ) 

  r  = rmin ; 
  dr = dr0 ;
  for  ud = 1:Ud
  for nr = 1:Nr
	if ( title )
		command = sprintf ("gset title \"r = %4f\"", r);
	    	eval (command);
	else 
		gset title "" ;
	endif
	if ( verbose )
		sprintf ("r = %4f", r)
		fflush(stdout) ; 
	endif

if (sigmoids)
  CCIMSIG ;
else
  CCIM ;
endif

	indicator = mybox( 0 , r , -2 , 0.5 ) ; 
	if ( data == 0 ) 
		v=randn(size(x))*M ;
		vl = bubblex( M , v , movieS , memory , x , indicator ) ;
	else
		infer ;

		if(firsttime) 
			plot ( xsub,t,style  ) ; 
			input("press return");
			firsttime = 0 ; 
		endif

		dv = randn(size(x)) * pp  ;
		if ( movieS > 0 ) 
		      vl = bubblexmd( pp , dv , movieS , memory , x , mean,xsub,t,indicator ) ;
		else # make a green picture ; xsubt is the data
			gplot xmsd u 1:2:3 w error 4 2 , xmean u 1:2 w l 4 2 ,xsubt u 1:2 w p 1 4 ,  indicator u 1:2 w l 7 8 ;
			pause(pausetime);

		endif

		if ( firstrun)
			lp = logprob2d(CsubI,t)  ;
			logPr(nr,:) = [ r , C(1,2) , lp , exp(lp) ] ;
		endif
	endif

	r = r * dr ;
endfor # nr
dr = 1/dr ;
r = r * dr ;
if(firstrun) firstrun=0 ; endif

endfor # ud

s = input("to repeat, type a number - ");
if ( s )
	pausetime = pausetime * s ;
else
 break ; endif
	purge_tmp_files ;
endwhile
gset nolabel 1

gset title ""

ret = logPr ; 



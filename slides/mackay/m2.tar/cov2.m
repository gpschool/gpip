function ret = cov2 ( xa , xb , r , jitter )
# make  covariance matrix, not necessarily square, for gaussian process 
  if (nargin != 4)
    usage ("cov (xa,xb,r,jitter) - xa,xb is vector, r is scalar");
  endif
global A ;

	s = size(xa);
	S=s(2);	
	xi = ones(size(xb))' * xa ;
	xj = xi' ;
	xi = ones(size(xa))' * xb ;
	dij = xi .- xj ;
	
	D = dij .^ 2 ;
	if ( jitter && (size(xb)==size(xa)) ) 
		ret = A * exp ( - D / (2*r^2) ) + jitter * eye ( S )  ;
	else
		ret = A * exp ( - D / (2*r^2) )  ;
	endif

endfunction

function ret = cov ( x , r )
# make exponential bit of covariance matrix for gaussian process 
  if (nargin != 2)
    usage ("cov (x,r) - x is vector, r is scalar");
  endif
	
	xi = ones(size(x))' * x ;
	xj = xi' ;
	dij = xi .- xj ;
	
	D = dij .^ 2 ;
	ret = exp ( - D / (2*r^2) ) ;
endfunction

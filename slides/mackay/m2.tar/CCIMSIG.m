# CCIM.m - makes C, CI, M, etc
				# using sigmoid C.K.I.W. covariance
C = covsigmoid( x, x , r , varbias , jitter ) ;
	if ( verbose >= 1 ) 
		input("press return");
	endif
	CI=inverse(C);
	M=chol(C);
	vars=diag(C);
	sds=sqrt(vars);

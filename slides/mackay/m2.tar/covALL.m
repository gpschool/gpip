function ret = covALL ( xa , xb , r , jitter )
# make  covariance matrix, not necessarily square, for gaussian process 
# this makes use of global variable A which controls amplitude
# and Ctype which says what type of cov we have.
# this works for one dimension only
# the Ctype says the function of distance that we are invoking; 
#   1 exp( -d^2 )
#   2 exp( -|d| )
#   3 cauchy 1/(1+d^2)
#   4 _/\_ 
#   5 sinc^2
# Csymmetry says whether we are ordinary (1), symmetric in 0 (2), 
# or periodic (3).
# CO says whether we are doing OHaganism (0/1)
#  spatially varying r....
  if (nargin != 4)
    usage ("covALL (xa,xb,r,jitter) - xa,xb is vector, r is scalar");
  endif
global A ;
global Ctype ;
global Csymmetry ;
global CO ;
global Calpha ;
global Cbeta ;

	s = size(xa);
	S=s(2);	

	if ( Csymmetry == 2 )  # mirror in 0 (style simplice)
		xa = abs(xa) ; xb = abs(xb) ; 
	endif

	xi = ones(size(xb))' * xa ;
	xj = xi' ;
	xi = ones(size(xa))' * xb ;
	dij = xi .- xj ;

	if ( Csymmetry == 3 )  # periodic functions with period 2pi
		dij = sin( dij / 2.0 ) ;
	endif
	
	if ( Ctype == 1 ) 
		D = dij .^ 2 ;
		ret = A * exp ( - D / (2*r^2) ) ;
	elseif ( Ctype == 2 ) 
		D = abs(dij) / r ; 
		ret = A * exp ( - D ) ;
	elseif ( Ctype == 3 ) 
	        D = dij .^ 2 ;
		ret = A ./(1.0 .+ D / (r^2) ) 
	elseif ( Ctype == 4 ) 
		D = r - abs(dij) ; 
		D = D .*  ( D >= 0.0 ) ;
		ret = A * D ; 
	elseif ( Ctype == 5 ) 
		D = dij / r ;
		ret = A * (sinc( D ) .^2) ; 
	else
		print "error Ctype\n" ; 
	endif

	if ( CO ) 
  	   for i=1:Sa
		for j=1:Sb
			F(i,j) = Oalpha + Obeta * (xa(1,i) * xb(1,j)) ;
			ret(i,j) = F(i,j) * ret(i,j) ;
		endfor
	   endfor
	endif

	if ( jitter && (size(xb)==size(xa)) ) 
		ret = ret + jitter * eye ( S )  ;
	endif

endfunction


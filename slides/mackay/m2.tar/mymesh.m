## Copyright (C) 1996 John W. Eaton 
##
## This file is part of Octave.
##
## Octave is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2, or (at your option)
## any later version.
##
## Octave is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with Octave; see the file COPYING.  If not, write to the Free
## Software Foundation, 59 Temple Place - Suite 330, Boston, MA
## 02111-1307, USA.

## usage: mesh (x, y, z)
##
## Surface plot.  If x, y, and z are matrices with the same dimensions,
## then corresponding elements represent vertices of the plot.  If x and
## y are vectors, then a typical vertex is (x(j), y(i), z(i,j)).  Thus,
## columns of z correspond to different x values and rows of z correspond
## to different y values.
##
## See also: plot, semilogx, semilogy, loglog, polar, meshgrid, meshdom,
##           contour, bar, stairs, gplot, gsplot, replot, xlabel, ylabel, title

## Author: jwe and djcm
				# the linestring modifier "ls" does not work

function zz = mymesh (x, y, z , hidden, color, linestring )
  assertivestyle = 0 ; # whether to switch a load of gnu settings
gset nohidden3d;
if ( nargin ==3 || nargin == 1 )
 hidden = 1 ;
 color = 1 ; 
      gset view 60, 30, 1, 1
endif
if ( nargin < 6 )
  linestring = "";
				# suggest using "ls" here if want to
endif

if (nargin == 1)
  z = x;
  if (is_matrix (z))
    if ( hidden )     
      gset hidden3d;
    endif
    gset data style lines;
    if ( assertivestyle )  #  djcm
      gset surface;
      gset nocontour;
    endif
				#      gset surface;
				#      gset nocontour; commented out djcm 9902
    gset noparametric;
    command = sprintf ( " gsplot z' w l %s %d ; " , linestring , color ) ; 
    eval ( command ) ; 
  else
    error ("mesh: argument must be a matrix");
  endif
elseif (nargin == 3 || nargin == 5 || nargin == 6)
  if (is_vector (x) && is_vector (y) && is_matrix (z))
    xlen = length (x);
    ylen = length (y);
    if (xlen == columns (z) && ylen == rows (z))
      if (rows (y) == 1)
        y = y';
      endif
      len = 3 * xlen;
      zz = zeros (ylen, len);
      k = 1;
      for i = 1:3:len
        zz(:,i)   = x(k) * ones (ylen, 1);
          zz(:,i+1) = y;
          zz(:,i+2) = z(:,k);
          k++;
        endfor
if ( hidden )     
	 gset hidden3d;
endif
	gset data style lines;
	if ( assertivestyle )  #  djcm
	  gset surface;
	  gset nocontour;
	endif
#        gset surface;
				#        gset nocontour; djcm
	gset parametric;
	command = sprintf ( " gsplot zz w l %s %d ; " , linestring , color ) ;
	eval ( command ) ; 
      else
        msg = "mesh: rows (z) must be the same as length (x) and";
        msg = sprintf ("%s\ncolumns (z) must be the same as length (y)", msg);
        error (msg);
      endif
    elseif (is_matrix (x) && is_matrix (y) && is_matrix (z))
      xlen = columns (z);
      ylen = rows (z);
      if (xlen == columns (x) && xlen == columns (y) &&
	ylen == rows (x) && ylen == rows(y))
        len = 3 * xlen;
        zz = zeros (ylen, len);
        k = 1;
        for i = 1:3:len
          zz(:,i)   = x(:,k);
          zz(:,i+1) = y(:,k);
          zz(:,i+2) = z(:,k);
          k++;
        endfor
if ( hidden )     
	 gset hidden3d;
endif
	gset data style lines;
	if ( assertivestyle )  #  djcm
	  gset surface;
	  gset nocontour;
	endif
	gset parametric;
	command = sprintf ( " gsplot zz w l %s %d ; " , linestring , color ) ;
	eval ( command ) ; 
      else
        error ("mesh: x, y, and z must have same dimensions");
      endif
    else
      error ("mesh: x and y must be vectors and z must be a matrix");
    endif
  else
    usage ("mesh (z)");
  endif

endfunction

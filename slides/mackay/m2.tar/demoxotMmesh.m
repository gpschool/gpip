function demoxotMmesh(x1,x2,o,t,r,S,movieS,memory,verbose)
# usage 
#
# x is a M * N matrix where M is the dimension of the space
# and N is the number of data points.
# o is a N vector
# so is t
# r is a vector of length M
# do a demo using inputs x, etc.
#
#  if (nargin != 6 && nargin != 7 && nargin != 8)
#    usage ("demoxotMmesh(x1,x2,o,t,r,S,movieS[,memory[,verbose]])");
#  endif
#  if (nargin != 7  && nargin != 8)
#	memory = 0.8 ; 
#  endif
#  if ( nargin != 8)
#	verbose = 1 ; 
#  endif

# S                     # number of samples
# movieS                # number of samples
global jitter ;
# jitter = 1e-4 ;
showdataalone = 0 ;

    [xx1, xx2] = meshgrid (x1, x2);
sx1 = size ( x1 ) ; 
sx2 = size ( x2 ) ; 
horiz = sx1(1);
vertic = sx2(1);
N = horiz * vertic ;

x = [ reshape( xx1 , 1 , N ) ;  reshape( xx2 , 1 , N ) ] 	;

s=size(x); X=s(2);
#  initgnu();			# set up graphics done elsewhere
#
# Make covariance matrix
#
	if ( verbose >= 1 ) 
		C = covM( x, x , r , jitter )
		input("press return");
	else 
C = covM( x, x , r , jitter ) ;
	endif
CIM ; 

# initialize one random sample and do a movie
alpha = 0.8 ;
hidden = 1 ; 
color = 6 ; 
v=randn(1,X)*M ;
z = reshape ( v , horiz , vertic ) ; 
    mymesh (x1, x2, z , hidden , color );

for l=1:movieS
	v = alpha * v + sqrt((1.0-alpha^2)) * randn(size(v))*M  ;
    z = reshape ( v , horiz , vertic ) ; 
    mymesh (x1, x2, z , hidden , color );

endfor

gset xrange [-2.5:2.5] ;
gset yrange [-2.5:2.5] ;
gset yzeroaxis  ;
gset xzeroaxis  ;

  gset autoscale xy ;
  gset logscale x
  gset title "log P( y1,y2 | A )"
	gplot  logPr u 1:3 w l 7 8
  input ( "hit return" );
  gset title "P( y1,y2 | A )"
	gplot  logPr u 1:4 w l 7 8

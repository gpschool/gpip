for l=1:X
	t=0;
	for  k1=1:K
		for  k2=k1:K
	  		t ++ ; H(k1,k2) = vs(t,l) ; 
			if ( k2 > k1 ) 
				H(k2,k1) = vs(t,l) ; 
			endif	
		endfor
	endfor
	V = sort(eig(H))' ;
	VS(l,:)=[x(1,l),V];
endfor

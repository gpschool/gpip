## octave code to generate 
## samples from two Gaussian processes:
## one for Brownian motion, one for 
## smooth gaussian-kernel case.

clear;
T = 200;
N=8 ;
r=39.0;
jitter = 1e-6;
t=[0:T];
for i=1:T
  for j=1:T
    C(i,j) = min(i,j) ;
    D(i,j) = exp ( - ( i-j)**2/(r**2)  ) ;
    theta=4;
    di = [theta i/r]; dj = [theta j/r];
    E(i,j) = (2.0/pi)*( asin(  2*di*dj'/sqrt( (1+2*di*di')*(1+2*dj*dj') ) ) ) ;
    theta=0;
    di = [theta i/r]; dj = [theta j/r];
    F(i,j) = (2.0/pi)*( asin(  2*di*dj'/sqrt( (1+2*di*di')*(1+2*dj*dj') ) ) ) ;
  end

### make things well conditioned by adding diagonal terms
  j=i ;
  C(i,j) = C(i,j) + jitter ; 
  D(i,j) = D(i,j) + jitter ; 
  E(i,j) = E(i,j) + jitter ; 
  F(i,j) = F(i,j) + jitter ; 

end

## cholesky decomposition is the square root.
U = chol(C);
				# want to sample v ~ N( C )
				# v = U * Normal(0,1)
gset nokey
n = randn( N, T );
u = n*U ;
figure(1);
plot(u')
V = chol(D);
v = n*V ;
figure(2);
plot(v');
W = chol(E);
w = n*W ;
figure(3);
plot(w');

X = chol(F);
x = n*X ;
figure(4);
plot(x');




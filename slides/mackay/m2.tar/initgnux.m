function initgnux ( x , ymin , ymax  )
I dont know how to get numbers through to gset.. 
 if ((nargin != 3))
    usage ("joinvector(t,tt,o)");
  endif

gset size 0.7,0.7
gset xrange [0.5:6.5]
gset clip one
gset yrange [-2.5:2.5]

function GPeigs(x,r,S,movieS,memory,verbose,K)
# usage 
# 
# do a demo using inputs x, etc.
  if (nargin != 7)
    usage ("GPeigs(x,r,S,movieS,memory,verbose,K)");
  endif

global jitter ;
global standard ;
showdataalone = 0 ;
sixteen = 16 ; # max number of lines to plot when showing H elements

s=size(x); X=s(2);
#
# Make covariance matrix
#
if ( standard )
	CCIM ; 
else 
	CCIML ; # linear variation in H_ij
endif
# command for plotting eigenvalues
if ( K <= sixteen )
	Kmaxplot = K ;
else
	Kmaxplot = sixteen ; 
endif
if ( K > 32 )
	Kminplot = K / 2 - 8 ;
	Kmaxplot = Kminplot + Kmaxplot ; 
else
	Kminplot = 1 ;
endif 
for k=Kminplot:Kmaxplot
	newcom = sprintf("VS u 1:%d w l %d",k+1,k) ;
	if ( k == Kminplot )
		coms = sprintf("%s",newcom);
	else
		coms = sprintf("%s, %s",coms,newcom);
	endif
endfor

# command for plotting entries of H
k=0; col=0;
for k1=1:K
  for k2=k1:K
	k++ ; # colour on-diagonal elements white;
	if ( k1 == k2 ) 
		thiscol = 8 ;
	else
		col ++ ; if ( col >= 8 ) col = 1 ; endif
		thiscol = col ; 
	endif
	newcom = sprintf("xvs u 1:%d w l %d",k+1,thiscol) ;
	if ( k == 1 )
		vscoms = sprintf("%s",newcom);
	else
		vscoms = sprintf("%s, %s",vscoms,newcom);
	endif
	if ( k >= sixteen ) break ; endif
  endfor	
  if ( k >= sixteen ) break ; endif
endfor
gset autos y ;
command = sprintf("gplot %s\n", coms );
vscommand = sprintf("gplot %s\n", vscoms );
# keyboard;
  substate = 1 ; 
  while (1)
	counter = 0 ; 
 purge_tmp_files ;
	if(++counter && substate==counter)
		eigsample ;
		eval(command);
	elseif (++counter && substate==counter)
		# show the lurking H dudes (no new sample)
		xvs = [x',vs'] ; 
		eval(vscommand);
	elseif (++counter && substate==counter)
		eigsample ;
		xvs = [x',vs'] ; 
		eval(vscommand);
	elseif (++counter && substate==counter)
		# eigsample ;
		eval(command);

	elseif (++counter && substate==counter)
		for s=1:movieS 
			eigmovie ;
			eval(command);
			printf(".");
		endfor
		printf("\n");

	elseif (++counter && substate==counter)
		break ;
	elseif (++counter && substate==counter)
		keyboard ;
	else
	  break;
	endif
	ans = mymenu("Eigenvalue model",
			"fresh eigenvalues","H","fresh H","eigenvalues","movie","quit","keyboard");
	if ( ans == 0 ) 
		substate ++ ;
	else
		substate = ans ;
	endif
  endwhile






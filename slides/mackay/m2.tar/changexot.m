function changexot ( s )
# changes the x,o,t, data set to a standard set indexed by s
global x;
global o;
global t;

counter = 0 ; 
if(++counter && s==counter)
  x=[1,2,3,4,5,6] ;
  o=[1,1,0,0,0,1] ;
  t=[1,1.25,0.1] ;
  gset xrange [0:7] ;

elseif (++counter && s==counter)
  x=[0, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6 , 7] ;
  gset xrange [-0.5:7.5] ;
  o=[0,0,0,0,0,1,0,1,0,1,0,0,0] ;
  t=[-1,-1.25,-0.1] ;

elseif ( ++counter && s==counter)
 x=[0:35]/5.0 ;
 o=zeros(size(x));
 o(1,7)=1; o(1,17)=1; o(1,12)=1;
 t=[-1,-1.25,-0.1] ;
elseif(++counter && s==counter)
  x=[-6,-5,-4,-3,-2,-1,-0.5,0,0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 5.5, 6 , 7] ;
  o=[0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,0,0] ;
  t=[-1,-1.25,-0.1] ;
  gset ytics
  gset xrange [-7.5:7.5] ;


else
	print "enter x,o,t then type quit e.g.";
	print "x=[1,2,3,4,5,6] ;"
	print "o=[1,1,0,0,0,1] ;"
	print "t=[1,1.25,0.1] ;"
 keyboard ;

endif
endfunction
	

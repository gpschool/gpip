# CCIML.m - makes C, CI, M, etc
	if ( verbose >= 1 ) 
		C = covL( x, x , r , jitter )
		input("press return");
	else 
		C = covL( x, x , r , jitter ) ;
	endif
	CI=inverse(C);
	M=chol(C);
	vars=diag(C);
	sds=sqrt(vars);

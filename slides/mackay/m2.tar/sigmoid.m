function ret = sigmoid ( v )
# sigmoid function 1/1=exp(v)
  if (nargin != 1)
    usage ("acot (z)");
  endif
	ret = 1.0 ./ ( 1.0 .+ exp ( - v ) ) ;
endfunction

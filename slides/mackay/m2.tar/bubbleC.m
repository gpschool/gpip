function ret = bubbleC ( M , v , L , alpha , x , subL , firsttime ,indicator ) 
# do a generative bubble tour of a gaussian 
# making plots versus x as we go , including geenrating classifcations
# firstime says whether to stop for return after showing the first plot
 if ((nargin != 8)&&(nargin != 7))
    usage ("bubblexC ( M , v , L , alpha , x , subL , firsttime [,indicator] )");
  endif
if (nargin == 8)
	indicatorgiven = 1 ;
else 
	indicatorgiven = 0;
endif

scale = 2.5 ;
	purge_tmp_files ;
	gset yrange [-2.5:3.6] ;
gset size  0.7, 0.9;
gset noytics; # -2,1,2 ;
gset label 1 "a" at 7.2,0.5 left
gset label 2 "p" at 7.2,2.5 left
gset label 3 "0" at 7.2,3.3 left
gset label 4 "1" at 7.4,3.4 left
	plainplot = 1 ; 
a0 = 3.3 ;
a1 = 3.4 ;
ap = 2.0 ;
surroundheight = 3.2 ; 
surroundheight2 = 3.5 ; 
surround2eight = 2;
surround2eight2 = 3 ; 
surround = [ -10, surroundheight  ; 0 , surroundheight ; 10 , surroundheight ;
	10, surroundheight2 ; 0 , surroundheight2 ; -10 , surroundheight2 ;
	-10 surroundheight ] ;
surround2 = [ -10, surround2eight  ; 0 , surround2eight ; 10 , surround2eight ;
	10, surround2eight2 ; 0 , surround2eight2 ; -10 , surround2eight2 ;
	-10 surround2eight ] ;
vl=[] ; 	
for l=1:L
#	purge_tmp_files ;
	v = alpha * v + sqrt((1.0-alpha^2)) * randn(size(v))*M  ;
	pv = sigmoid ( scale * v ) ;
	vl(l,:) = [pv] ;
	apv = pv + ap ;
	xvtot = [ x' , v' ] ;
	xpv = [ x' , apv' ] ;
	for subl=1:subL
		t = randb ( pv ) ;
		nott = 1  - t ;
		x0 = subvector ( x , t ) ; 
		x1 = subvector ( x , nott ) ; 
		x0a = [ x0 , a0 * ones( size(x0) ) ; 10 , 10 ] ;
		x1a = [ x1 , a1 * ones( size(x1) ) ; 10 ,10.2 ] ;
		if ( plainplot ) 
		    if ( indicatorgiven )
			gplot xvtot u 1:2 w linespoints 6 3 , indicator u 1:2 w l 7 8 ;
		    else
			gplot surround u 1:2 w lines 8 8, surround2 u 1:2 w lines 8 8 ,		xvtot u 1:2 w lines 6 3 , xpv u 1:2 w lines 7 7 , 			 x0a u 1:2 w p 3 3 , x1a u 1:2 w p 5 6 ;
		    endif
		endif
		if ( firsttime ) 
			firsttime = 0 ;
			input ( "press return for movie" );
		endif
	endfor

endfor
gset ytics;
gset nolabel 1;
gset nolabel 2;
gset nolabel 3;
gset nolabel 4;
ret = vl ;
endfunction

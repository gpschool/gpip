function ret = covL ( xa , xb , r , jitter )
# covL - linear regression covariance funcytion 
# make  covariance matrix, not necessarily square, for gaussian process 
  if (nargin != 4)
    usage ("cov (xa,xb,r,jitter) - xa,xb is vector, r is scalar");
  endif
global A ;

	s = size(xa);
	S=s(2);	
	xi = ones(size(xb))' * (xa-3.5) ;
	xj = xi' ;
	xi = ones(size(xa))' * (xb-3.5) ;
	dij = xj * xi;
	
	if ( jitter && (size(xb)==size(xa)) ) 
		ret =  1.0 + dij / (2*r^2)  + jitter * eye ( S )  ;
	else
		ret =  1.0 + dij / (2*r^2)   ;
	endif

endfunction
